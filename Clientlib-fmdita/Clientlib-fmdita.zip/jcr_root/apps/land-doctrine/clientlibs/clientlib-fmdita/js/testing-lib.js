// for hosted js library
console.log('testing lib is working!')